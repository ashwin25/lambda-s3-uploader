import boto3

def db_util(obj, table_name, region):
    try:
        dyndb = boto3.client('dynamodb', region_name=region)
        response = dyndb.put_item(TableName=table_name, Item=obj)
        return response
    except Exception as e:
        print(e)